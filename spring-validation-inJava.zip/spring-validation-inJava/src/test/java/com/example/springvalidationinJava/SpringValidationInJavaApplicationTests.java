package com.example.springvalidationinJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringValidationInJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
