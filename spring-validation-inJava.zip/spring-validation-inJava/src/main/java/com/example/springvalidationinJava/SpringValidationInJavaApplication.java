package com.example.springvalidationinJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringValidationInJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringValidationInJavaApplication.class, args);
	}

}
